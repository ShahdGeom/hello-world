﻿define(
	 ({
		commonMapControls: {
			common: {
				settings: "设置",
				openDefault: "默认打开"
			},
			overview: {
				basemapGalleryBtnLabel: "底图",
				expandFactorLabel: "扩展因子",
				expandFactorPopover: "鹰眼图大小和鹰眼图上显示的范围矩形大小之比。默认值为 2，表示鹰眼图至少为范围矩形大小的两倍。"
			}
		}
	})
);
