﻿define(
	 ({
		commonMapControls: {
			common: {
				settings: "Asetukset",
				openDefault: "Avaa oletusarvoisesti"
			},
			overview: {
				basemapGalleryBtnLabel: "Taustakartta",
				expandFactorLabel: "Laajenna tekijä",
				expandFactorPopover: "Yleiskatsauskartan koon ja yleiskatsauskartalla näkyvän laajuussuorakulmion välinen suhde. Oletusarvo on 2, mikä tarkoittaa, että yleiskatsauskartta on vähintään kaksi kertaa laajuussuorakulmion kokoinen."
			}
		}
	})
);
