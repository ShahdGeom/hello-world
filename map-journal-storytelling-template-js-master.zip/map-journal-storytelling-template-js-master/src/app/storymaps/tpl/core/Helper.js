define([], 
	function(){
		return {
			//
		};
	}
);